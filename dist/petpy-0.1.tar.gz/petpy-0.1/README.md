# petpy

Petrophysical utilities

## Installing

....pip unstall petpy
    python setup.py sdist
    pip install dist/petpy-0.2.tar.gz

## Developing

    pip install -r requirements.txt
